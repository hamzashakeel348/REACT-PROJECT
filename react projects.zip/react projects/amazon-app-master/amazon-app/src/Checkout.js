import React from "react";
import "./Checkout.css";
import CheckProduct from "./CheckProduct";
import Subtotal from "./Subtotal";
import { useStateValue } from "./StateProvider";
function Checkout() {
  const [{ basket }, dispatch] = useStateValue();

  return (
    <div className="checkout">
      <img className="checkout_image" src="/images/aala.PNG" alt="" />
      {basket.length > 0 && (
        <div className="checkout_subtotal">
          <h1>Subtotal</h1>
          <Subtotal />
        </div>
      )}
      {basket.length === 0 ? (
        <div>
          <h2>Your Shopping Cart is Empty</h2>
          <p>
            You have nothing in your Basket. Add something to cart and then
            proceed to checkout.
          </p>
          <h3>Happy Shopping!!!</h3>
        </div>
      ) : (
        <div>
          <h2 className="checkout_title">Your Shopping Cart</h2>
          <hr></hr>
          {basket.map((item) => (
            <CheckProduct
              id={item.id}
              title={item.title}
              image={item.image}
              price={item.price}
              ratings={item.ratings}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default Checkout;
