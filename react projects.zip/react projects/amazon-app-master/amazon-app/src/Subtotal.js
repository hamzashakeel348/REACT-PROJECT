import React from "react";
import { useStateValue } from "./StateProvider";
import CurrencyFormat from "react-currency-format";
import { total } from "./reducer";
import "./subtotal.css";
function Subtotal() {
  const [{ basket }, dispatch] = useStateValue();
  return (
    <div className="Subtotal">
      <button className="but">Proceed to Checkout</button>
      <br></br>
      <CurrencyFormat
        renderText={(value) => (
          <p>
            Subtotal({basket.length}items): <strong>{value}</strong>
          </p>
        )}
        decimalScale={2}
        value={total(basket)}
        displayType={"text"}
        thousandSeparator={true}
        prefix={"$"}
      />
      <br></br>
    </div>
  );
}

export default Subtotal;
