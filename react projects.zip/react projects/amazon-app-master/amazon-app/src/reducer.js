export const initialState = {
  basket: [
    {
      id: "12342441",
      title: "Apple iPad Pro 3 12.9",
      price: 589.99,
      rating: 4,
      image: "./images/ipad.jfif",
    },
  ],
  user: null,
};
export const total = (basket) =>
  basket.reduce((amount, item) => item.price + amount, 0);
const reducer = (state, action) => {
  switch (action.type) {
    case "Add to Cart":
      return {
        ...state,
        basket: [...state.basket, action.item],
      };
    case "Remove from Cart":
      let newbasket = [...state.basket];

      const index = state.basket.findIndex(
        (basketItem) => basketItem.id === action.id
      );
      if (index >= 0) {
        newbasket.splice(index, 1);
      } else {
      }
      return {
        ...state,
        basket: newbasket,
      };
    default:
      return state;
  }
};

export default reducer;
