import React from "react";
import "./product.css";
import { BsStarFill } from "react-icons/bs";
import { useStateValue } from "./StateProvider";

function Product({ id, title, image, price, ratings }) {
  const [{}, dispatch] = useStateValue();

  const addtoBasket = () => {
    dispatch({
      type: "Add to Cart",
      item: {
        id: id,
        title: title,
        image: image,
        price: price,
        ratings: ratings,
      },
    });
  };

  return (
    <div className="Product">
      <div className="Product_info">
        <p>{title}</p>
        <p className="Product_price">
          <strong>${price}</strong>
        </p>
        <div className="Product_rating">
          {Array(ratings)
            .fill()
            .map((_) => (
              <BsStarFill className="Product_Icon" />
            ))}
        </div>
      </div>
      <img className="Product_images" src={image} alt="" />
      <button onClick={addtoBasket}>Add to cart</button>
    </div>
  );
}

export default Product;
