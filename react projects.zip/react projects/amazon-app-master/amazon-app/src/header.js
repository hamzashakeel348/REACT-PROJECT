import React from "react";
import "./header.css";
import { MdShoppingBasket } from "react-icons/md";
import { MdSearch } from "react-icons/md";
import { Link } from "react-router-dom";
import { useStateValue } from "./StateProvider";

function Header() {
  const [{ basket }] = useStateValue();

  return (
    <nav className="Header">
      <Link to="/">
        <img
          className="Header_logo"
          src="http://pngimg.com/uploads/amazon/amazon_PNG11.png"
          alt="hamza"
        />
      </Link>
      <div className="jh">
        <input
          placeholder="Search"
          type="text"
          className="Header_searchInput"
        />
        <MdSearch className="Header_search" />
      </div>

      <div className="Header_nav">
        <Link to="/login" className="Header_link">
          <div className="Header_option">
            <span className="Header_option-1">Hello Hamza</span>
            <span className="Header_option-2">Sign In</span>
          </div>
        </Link>

        <Link to="/" className="Header_link">
          <div className="Header_option">
            <span className="Header_option-1">Returns</span>
            <span className="Header_option-2">& Orders</span>
          </div>
        </Link>

        <Link to="/" className="Header_link">
          <div className="Header_option">
            <span className="Header_option-1">Your</span>
            <span className="Header_option-2">Prime</span>
          </div>
        </Link>
        <Link to="/checkout" className="Header_link">
          <div className="Header_optionbasket">
            <MdShoppingBasket className="Icon" />
            <span className="Icon">{basket.length}</span>
          </div>
        </Link>
      </div>
    </nav>
  );
}

export default Header;
