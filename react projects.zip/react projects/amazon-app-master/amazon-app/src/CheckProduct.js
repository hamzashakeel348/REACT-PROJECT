import React from "react";
import "./CheckProduct.css";
import { BsStarFill } from "react-icons/bs";
import { useStateValue } from "./StateProvider";
function CheckProduct({ id, title, image, price, ratings }) {
  const [{ basket }, dispatch] = useStateValue();

  const removefromBasket = () => {
    dispatch({
      type: "Remove from Cart",
      id: id,
    });
  };
  return (
    <div className="checkoutProduct">
      <img className="check_Image" src={image} alt="" />
      <div className="checkoutProduct_info">
        <p className="checkoutProduct_title">{title}</p>
        <p className="checkoutProduct_price">
          <strong>${price}</strong>
        </p>

        <div className="checkoutProduct_rating">
          {Array(ratings)
            .fill()
            .map((_) => (
              <BsStarFill className="Product_Icon" />
            ))}
        </div>

        <button className="b" onClick={removefromBasket}>
          Remove from cart
        </button>
      </div>
    </div>
  );
}

export default CheckProduct;
