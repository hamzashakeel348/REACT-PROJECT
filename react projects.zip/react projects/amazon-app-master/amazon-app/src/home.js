import React from "react";
import "./home.css";
import Product from "./product";
function home() {
  return (
    <div className="Home">
      <img className="Home_Image" src="/images/dai.PNG" alt="hamza" />
      <div className="Home_row">
        <Product
          id="1"
          title="OPPO A1K"
          price={450}
          ratings={2}
          image="/images/a1k.PNG"
        />
        <Product
          id="12345"
          title="Baby Pampers"
          price={210}
          ratings={4}
          image="/images/a2k.jpg"
        />
      </div>
      <div className="Home_row">
        <Product
          id="12345"
          title="CHITTO Clutch Pencil"
          price={20}
          ratings={3}
          image="/images/1.PNG"
        />
        <Product
          id="12345"
          title="Xiamoi Airdots S"
          price={35}
          ratings={4}
          image="/images/a.jpg"
        />
        <Product
          id="12345"
          title="Led Lights"
          price={100}
          ratings={4}
          image="/images/l1.jfif"
        />
      </div>
      <div className="Home_row">
        <Product
          id="12345"
          title="Women Bag"
          price={35}
          ratings={5}
          image="/images/b.jpg"
        />
      </div>
    </div>
  );
}

export default home;
