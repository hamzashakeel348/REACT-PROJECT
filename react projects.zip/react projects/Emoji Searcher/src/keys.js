module.exports = {
  API_KEY: "1cacc5f5db50d6c040c2951584c637965086c6da",
  URL: "https://emoji-api.com/emojis",
};
